# <%=project_name%>

<%=project_name%>: built using the [WebSDK](https://websdk.rbsgrp.net/) with [Create React App](https://facebook.github.io/create-react-app/).

The Application is using WebSDK, [Formidable](http://websdk.rbsgrp.net/?path=/story/formidable-components-formidable--basic) and [Formidable Components](http://websdk.rbsgrp.net/?path=/story/formidable-components-inputfield--basic).

## Customisation

This is a sample application. You will need to update:
- the application `name` and `short_name` in [`public/manifest.json`](public/manifest.json),
- change the `<title>` in [`public/index.html`](public/index.html),
- swap [`public/favicon.ico`](public/favicon.ico),
- and replace [`src/App.js`](src/App.js) with your own application.

To change the theme of the application, you will need to update:
- the `class` on the `body` in [`public/index.html`](public/index.html),
- change the imported `icon` set and `theme.min.css` path in [`src/index.js`](src/index.js)
