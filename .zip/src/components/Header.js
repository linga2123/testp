import React from 'react'
import './Header.css'
const Header =()=>{
    return(
       <div className="h">
         <div className="h-left">
           <div className="left-wrapper">
         <div className="rbs-main">
         <h1 className="rbs" >RBS</h1>
         </div>
           
           <div className="long">
           <h5 className="text-long">The Royal Bank Of Scotland</h5>
           </div>



           </div>
         <div className="btn">
         <button style={{color:"red"}}>Administration</button>
         </div>

         </div>
         <div className="h-right">
<div className="right-wrapper">
  <h1 className="text">Bank User:HSUDFDTFTYSUKDD</h1>
<h1 className="login">You Last Loged In On: {new Date().getDate()}</h1>
</div>
         </div>

       </div>
    )
}
export default Header