import React from 'react'
import './SideBar.css'
const SideBar =()=>{
    return(
        <div className="sidebar">
       <div className="side-wrapper">
           <div className="roles-section">
               <h6 className="role">Roles</h6>
               <hr/>
               <ul className="role-list">
                   <li>Manage Roles</li>
                   <li>Create a new Role</li>
               </ul>
           </div>
           <div>
               <h6>Actions</h6>
               <hr/>
               <ul>
                   <li>Search for audit Record</li>
                   <li>Authorise changes</li>
               </ul>
           </div>
           <div>
               <h6>Bank Administration</h6>
               <hr/>
               <ul>
                   <li>Home</li>
                   <li>Create bank user profile</li>
                   <li>Manage Bank organizations</li>
                   <li>Search for bank user profile</li>
               </ul>
           </div>

       </div>
       
        </div>
    )
}
export default SideBar