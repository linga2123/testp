import React from 'react'
import { Icon } from '@zambezi/sdk/icons'
import Signup from './Signup'
import Header from './components/Header'
import SideBar from './components/SideBar'

function App () {
  return (
    <div className='App'>
    <div>
      <Header />
      
      <aside>

        <SideBar />
      </aside>
    </div>
     
    </div>
  )
}

export default App
