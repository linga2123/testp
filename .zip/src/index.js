

import React from 'react'
import ReactDOM from 'react-dom'

// Prepare to work with WebSDK: http://websdk.rbsgrp.net/
import '@zambezi/sdk-themes/zb-natwest-group-standard/icons'
import '@zambezi/sdk-themes/zb-natwest-group-standard/theme.min.css'
import '@zambezi/formidable-components/dist/formidable-components.min.css'

// Load application specific parts
import './index.css'
import App from './App'
import * as serviceWorker from './serviceWorker'

ReactDOM.render(<App />, document.getElementById('root'))

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister()
